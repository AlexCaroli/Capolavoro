package com.example.polofitness;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class AllenamentoActivity extends AppCompatActivity {

    private ArrayList<Allenamento> allenamenti;
    private EditText txtNome;
    private ListView listElencoAllenamenti;
    private ArrayAdapter<String> adapterAllenamenti;

    public final static String file = "allenamenti.txt";
    private File archivio;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allenamento);

        listElencoAllenamenti = findViewById(R.id.listElencoAllenamenti);
        adapterAllenamenti = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        listElencoAllenamenti.setAdapter(adapterAllenamenti);
        caricaDaFile();

        // Recupera l'oggetto Allenamento dall'Intent
        Intent intent = getIntent();
        if (intent != null) {
            Allenamento allenamento = intent.getParcelableExtra("NuovoAllenamento");
            int position = intent.getIntExtra("PosizioneAllenamentoNonModificato", -1);
            if (allenamento != null) {
                if (position != -1) {    //si è passati dall'activity NuovoAllenamento a AllenamentoActivty tramite il tasto Indietro della navigationBar
                    allenamenti.add(position, allenamento);
                    adapterAllenamenti.insert(allenamento.toString(), position);
                    //Log.i("POSZIONE","ALLENAMENTO AGGIUNTO IN POSIZIONE " + position);
                } else { //si è passati dall'activity NuovoAllenamento a AllenamentoActivty tramite il bottone per aggiungere un nuovo allenamento
                    allenamenti.add(allenamento);
                    adapterAllenamenti.add(allenamento.toString());
                    //Log.i("POSZIONE","ALLENAMENTO AGGIUNTO IN ULTIMA POSIZIONE");
                }
                salvaSuFile(allenamenti);
            }
        }
        listElencoAllenamenti.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                iniziaAllenamento(position);
            }
        });
        listElencoAllenamenti.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                modificaEliminaAllenamento(position);
                return true;
            }
        });
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Intent intent = new Intent(AllenamentoActivity.this, MainActivity.class);
                startActivity(intent);
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    public void nuovoAllenamento(View view) {
        Intent intent = new Intent(this, NuovoAllenamentoActivity.class);
        startActivity(intent);
    }

    public void salvaSuFile(ArrayList<Allenamento> allenamenti) {
        FileOutputStream fos = null;
        ObjectOutputStream os = null;
        try {
            fos = openFileOutput(file, Context.MODE_PRIVATE);
            os = new ObjectOutputStream(fos);
            os.writeObject(allenamenti);
            os.close();
            fos.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void caricaDaFile() {
        FileInputStream fis = null;
        ObjectInputStream is;
        try {
            fis = openFileInput(file);
            is = new ObjectInputStream(fis);
            allenamenti = (ArrayList<Allenamento>) is.readObject();
            adapterAllenamenti.clear();
            for (Allenamento temp : allenamenti) {
                adapterAllenamenti.add(temp.toString());
            }
            is.close();
            fis.close();
        } catch (IOException | ClassNotFoundException e) {
            archivio = new File(file);
            allenamenti = new ArrayList<>();
            //Log.i("caricaDaFile", "FILE NON PRESENTE");
        }
    }

    public void modificaEliminaAllenamento(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.opzioniAllenamento)
                .setNeutralButton(R.string.annulla, null)
                .setNegativeButton(R.string.modifica, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        modificaAllenamento(position);
                    }
                })
                .setPositiveButton(R.string.elimina, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        eliminaAllenamento(position);
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(AllenamentoActivity.this, R.color.actionBarBackground));
                alertDialog.getButton(DialogInterface.BUTTON_NEUTRAL).setTextColor(ContextCompat.getColor(AllenamentoActivity.this, R.color.actionBarBackground));
                alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(AllenamentoActivity.this, R.color.actionBarBackground));
            }
        });
        alertDialog.show();
    }

    public void modificaAllenamento(int position) {
        Intent intent = new Intent(this, NuovoAllenamentoActivity.class);
        intent.putExtra("AllenamentoDaModificare", (Parcelable) allenamenti.remove(position));   //rimuovo dalla lista degli allenamenti disponibili quello che sta per essere modificato
        intent.putExtra("PosizioneAllenamento", position);
        salvaSuFile(allenamenti);   //salvo su file la lista aggiornata
        startActivity(intent);
    }

    public void eliminaAllenamento(int position) {
        //Log.i("ELIMINA", "ELIMINATO ALLENAMENTO " + position);
        allenamenti.remove(position);
        salvaSuFile(allenamenti);
        adapterAllenamenti.clear();
        for (Allenamento temp : allenamenti) {
            adapterAllenamenti.add(temp.toString());
        }
    }

    public void iniziaAllenamento(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.iniziareAllenamento)
                .setNegativeButton(R.string.no, null)
                .setPositiveButton(R.string.si, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        iniziaTimer(position);
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(AllenamentoActivity.this, R.color.actionBarBackground));
                alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(AllenamentoActivity.this, R.color.actionBarBackground));
            }
        });
        alertDialog.show();
    }

    public void iniziaTimer(int position) {
        Intent intent = new Intent(this, IniziaAllenamentoActivity.class);
        intent.putExtra("AllenamentoScelto", (Parcelable) allenamenti.get(position));
        startActivity(intent);
    }
}