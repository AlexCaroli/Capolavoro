package com.example.polofitness;

import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Allenamento implements Parcelable, Serializable {

    private String nome;
    private ArrayList<Esercizio> esercizi;
    private LocalDateTime data;
    public Allenamento(String nome, ArrayList<Esercizio> esercizi) {
        this.nome = nome;
        this.esercizi = esercizi;
    }
    public void setData(LocalDateTime data) {
        this.data = data;
    }
    public LocalDateTime getData() {
        return data;
    }

    public String getNome() {
        return nome;
    }

    public ArrayList<Esercizio> getEsercizi() {
        return esercizi;
    }

    public Esercizio getEsercizio(int position) {
        return esercizi.get(position);
    }

    @Override
    public String toString() {
        return nome;
    }

    public String toStringData() {
        if (data != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                return nome + " " + data.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"));
            }
        }
        return nome;
    }
    //metodi dell'interfaccia Parcelable
    protected Allenamento(Parcel in) {
        nome = in.readString();
        esercizi = in.createTypedArrayList(Esercizio.CREATOR);
    }

    public static final Parcelable.Creator<Allenamento> CREATOR = new Parcelable.Creator<Allenamento>() {
        @Override
        public Allenamento createFromParcel(Parcel in) { //si leggono i dati dal Parcel
            return new Allenamento(in);
        }

        @Override
        public Allenamento[] newArray(int size) {   //usato quando si deserializza un array di Parcelable, per ogni elemento dell'array viene chiamato createFromParcel
            return new Allenamento[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) { //si scrivono tutti gli attributi della classe, LocalDateTime non implementa l'interfaccia Parcelable
        dest.writeString(nome);
        dest.writeTypedList(esercizi);
    }
}
