package com.example.polofitness;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Chronometer;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;

import android.view.LayoutInflater;

public class IniziaAllenamentoActivity extends AppCompatActivity implements CustomDialogPesoListener {
    private Chronometer chronometer;
    private TextView txtAllenamentoInCorso;
    private Allenamento allenamentoInCorso;
    private ListView listEsercizi;
    private ArrayAdapter adapter;
    private boolean pausa; //false: non è in pause, true: è in pausa
    private long durataPausa;
    public final static String file = "risultati.txt";
    private File risultati;
    private int ultimoElementoCliccato;

    private boolean uscitaConSalvataggio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inizia_allenamento);

        txtAllenamentoInCorso = findViewById(R.id.txtAllenamentoInCorso);
        listEsercizi = findViewById(R.id.listEsercizi);
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1);
        listEsercizi.setAdapter(adapter);

        Intent intent = getIntent();
        if (intent != null) {
            allenamentoInCorso = intent.getParcelableExtra("AllenamentoScelto");
            if (allenamentoInCorso != null) {
                txtAllenamentoInCorso.setText(txtAllenamentoInCorso.getText().toString() + " " + allenamentoInCorso.getNome());
                for (Esercizio temp : allenamentoInCorso.getEsercizi()) {
                    adapter.add(temp.toString());
                }
            }
        }

        chronometer = findViewById(R.id.chronometer);
        chronometer.setFormat("%H:%m:%s");//imposta il formato del cronometro per visualizzare ore,minuti e secondi
        chronometer.setBase(SystemClock.elapsedRealtime());//fa partire il cronometro da 0
        startChronometer(findViewById(android.R.id.content));

        listEsercizi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                inserisciPesoUtilizzato(position);
            }
        });
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
               fineAllenamento();
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);
    }


    public void inserisciPesoUtilizzato(int position) {
        ultimoElementoCliccato = position;
        CustomDialogPeso customDialog = new CustomDialogPeso(allenamentoInCorso.getEsercizio(position));
        customDialog.setCustomDialogListener(this);

        FragmentManager fragmentManager = getSupportFragmentManager();
        customDialog.show(fragmentManager, "CustomDialog");
    }

    @Override
    public void onSaveClicked(ArrayList<String> pesiInseriti) {
        ArrayList<Float> pesiUsati = new ArrayList<>();
        for (int i = 0; i < pesiInseriti.size(); i++) {
            try {
                if (Float.parseFloat(pesiInseriti.get(i)) != -1)
                    pesiUsati.add(Float.parseFloat(pesiInseriti.get(i)));
            } catch (
                    NumberFormatException ex) {  //non è stato inserito il valore nella CustomDialgPeso
                pesiUsati.add((float) -1);
            }
        }
        allenamentoInCorso.getEsercizio(ultimoElementoCliccato).setPesiUsati(pesiUsati);
        /*for(int i = 0; i< allenamentoInCorso.getEsercizio(ultimoElementoCliccato).getNumSerie(); i++){
            Log.i("PESO " + i, allenamentoInCorso.getEsercizio(ultimoElementoCliccato).getPesoUsato(i)+"");
        }*/
    }

    public void startChronometer(View view) {
        chronometer.start();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {   //disponibile se API >=26
            allenamentoInCorso.setData(LocalDateTime.now());
        }
    }

    public void startChronometer() {
        chronometer.start();
    }
    public void stopChronometer() {
        chronometer.stop();
    }

    public void resetAllenamento(View view) {
        pausaAllenamento(view);
        confermaReset();
        //Log.i("RESET", "HO FATTO IL RESET");

    }
    private void confermaReset() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.custom_dialog_peso, null);
            builder.setMessage(R.string.confermaFineAllenamentoSenzaSalvare)
                    .setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            pausaAllenamento();
                        }
                    })
                    .setPositiveButton(R.string.si, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            for (int i = 0; i < allenamentoInCorso.getEsercizi().size(); i++) {
                                for (int j = 0; j < allenamentoInCorso.getEsercizio(i).getNumSerie(); j++) {
                                    allenamentoInCorso.getEsercizio(i).setPesoUsato((float) -1, j);
                                }
                            }
                            chronometer.setBase(SystemClock.elapsedRealtime());
                            startChronometer();
                        }
                    });
        AlertDialog alertDialog = builder.create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(IniziaAllenamentoActivity.this, R.color.actionBarBackground));
                alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(IniziaAllenamentoActivity.this, R.color.actionBarBackground));
            }
        });
        alertDialog.show();
    }
    public void pausaAllenamento(View view) {
        if (pausa) {
            chronometer.setBase(SystemClock.elapsedRealtime() - durataPausa);//Imposta il cronometro per ripartire dal tempo in pausa
            startChronometer();
        } else {
            stopChronometer();
            durataPausa = SystemClock.elapsedRealtime() - chronometer.getBase();
        }
        pausa = !pausa;
    }
    public void pausaAllenamento() {
        if (pausa) {
            chronometer.setBase(SystemClock.elapsedRealtime() - durataPausa);//Imposta il cronometro per ripartire dal tempo in pausa
            startChronometer();
        } else {
            stopChronometer();
            durataPausa = SystemClock.elapsedRealtime() - chronometer.getBase();
        }
        pausa = !pausa;
    }

    public void fineAllenamento(View view) {
        uscitaConSalvataggio = true;
        pausaAllenamento(view);
        confermaUscita();
    }
    public void fineAllenamento() {
        uscitaConSalvataggio = false;
        pausaAllenamento();
        confermaUscita();
    }
    private void confermaUscita() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.custom_dialog_peso, null);
        if(uscitaConSalvataggio) {  //bottone FINE
            builder.setMessage(R.string.confermaFineAllenamento)
                    .setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            pausaAllenamento();
                        }
                    })
                    .setPositiveButton(R.string.si, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            riempiEserciziVuoti();
                            salvaSuFile(allenamentoInCorso);
                            tornaAllaHome();
                        }
                    });
        }else { //bottone tornaIndietro
            builder.setMessage(R.string.confermaFineAllenamentoSenzaSalvare)
                    .setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            pausaAllenamento();
                        }
                    })
                    .setPositiveButton(R.string.si, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            tornaAllaHome();
                        }
                    });
        }

        AlertDialog alertDialog = builder.create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(IniziaAllenamentoActivity.this, R.color.actionBarBackground));
                alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(IniziaAllenamentoActivity.this, R.color.actionBarBackground));
            }
        });
        alertDialog.show();
    }

    private void riempiEserciziVuoti() {
        for (int i = 0; i < allenamentoInCorso.getEsercizi().size(); i++) {
            for (int j = 0; j < allenamentoInCorso.getEsercizio(i).getPesiUsati().size(); j++) {
                if (allenamentoInCorso.getEsercizio(i).getPesoUsato(j) == -1) {
                    allenamentoInCorso.getEsercizio(i).setPesoUsato(0f, j);
                }
            }
        }
    }

    private void tornaAllaHome() {
        Intent intent = new Intent(IniziaAllenamentoActivity.this, MainActivity.class);
        startActivity(intent);
    }

    public void salvaSuFile(Allenamento nuovoAllenamento) {
        FileOutputStream fos = null;
        ObjectOutputStream os = null;
        ArrayList<Allenamento> allenamenti = caricaDaFile();
        allenamenti.add(nuovoAllenamento);
        try {
            fos = openFileOutput(file, Context.MODE_PRIVATE);
            os = new ObjectOutputStream(fos);
            os.writeObject(allenamenti);
            os.close();
            fos.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<Allenamento> caricaDaFile() {
        FileInputStream fis = null;
        ObjectInputStream is;
        ArrayList<Allenamento> allenamenti;
        try {
            fis = openFileInput(file);
            is = new ObjectInputStream(fis);

            allenamenti = (ArrayList<Allenamento>) is.readObject();
            //Log.i("caricaDaFileIniziaAllenamento", "HO LETTO GLI OGGETTI GIA' PRESENTI");
            is.close();
            fis.close();
            return allenamenti;
        } catch (IOException | ClassNotFoundException e) {
            risultati = new File(file);
            //Log.i("caricaDaFileIniziaAllenamento", "FILE NON PRESENTE");
            return new ArrayList<>();
        }
    }
}
