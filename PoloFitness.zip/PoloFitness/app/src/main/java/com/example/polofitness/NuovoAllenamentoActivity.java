package com.example.polofitness;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class NuovoAllenamentoActivity extends AppCompatActivity {
    private ArrayList<Esercizio> esercizi;
    private EditText txtNome;
    private ListView listElencoEsercizi;
    private ArrayAdapter<String> adapterEsercizi;

    private Allenamento allenamentoDaModificare;
    private int tempPosition;   //variabile contenente la posizione originale dell'allenamento da modificare

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuovo_allenamento);

        esercizi = new ArrayList<>();
        txtNome = findViewById(R.id.txtNome);
        listElencoEsercizi = findViewById(R.id.listEsercizi);
        adapterEsercizi = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        listElencoEsercizi.setAdapter(adapterEsercizi);

        Intent intent = getIntent();
        if (intent != null) {
            allenamentoDaModificare = intent.getParcelableExtra("AllenamentoDaModificare");
            tempPosition = intent.getIntExtra("PosizioneAllenamento", -1);
            if (allenamentoDaModificare != null) {
                txtNome.setText(allenamentoDaModificare.getNome());
                esercizi.addAll(allenamentoDaModificare.getEsercizi());
                for (Esercizio temp : allenamentoDaModificare.getEsercizi()) {
                    adapterEsercizi.add(temp.toString());
                }
            }
        }
        listElencoEsercizi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                modificaEliminaEsercizio(position);
            }
        });

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                modificheNonSalvate(findViewById(R.id.listEsercizi));
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);
    }


    public void modificheNonSalvate(View view) {
        if (allenamentoDaModificare != null) {   //modifica di un allenamento esistente
            if (allenamentoDaModificare.getNome().equals(txtNome.getText().toString()) && allenamentoDaModificare.getEsercizi().equals(esercizi)) {  //non sono state fatte modifiche
                tornaIndietro();
            } else { //sono state fatte modifiche
                confermaUscita();
            }
        } else {    //creazione di un nuovo allenamento
            if (txtNome.getText().toString().equals("") && esercizi.isEmpty()) {    //non sono state inserite informazioni sul nuovo allenamento
                tornaIndietro();
            } else {    //sono state fatte modifiche
                confermaUscita();
            }
        }
    }

    private void confermaUscita() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.confermaSenzaModifiche)
                .setNegativeButton(R.string.annulla, null)
                .setPositiveButton(R.string.si, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        tornaIndietro();
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(NuovoAllenamentoActivity.this, R.color.actionBarBackground));
                alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(NuovoAllenamentoActivity.this, R.color.actionBarBackground));
            }
        });
        alertDialog.show();
    }

    private void tornaIndietro() {
        Intent intent = new Intent(NuovoAllenamentoActivity.this, AllenamentoActivity.class);
        intent.putExtra("NuovoAllenamento", (Parcelable) allenamentoDaModificare);
        intent.putExtra("PosizioneAllenamentoNonModificato", tempPosition);
        startActivity(intent);
    }

    public void salvaAllenamento(View view) {
        Allenamento allenamento = new Allenamento(txtNome.getText().toString(), esercizi);
        if (!allenamento.getNome().trim().isEmpty()) {   //rimuove tutti gli spazi prima e dopo il testo e controlla che non equivalga a ""
            if (controlloNomeUnivocoAllenamento(allenamento)) {
                Intent intent = new Intent(this, AllenamentoActivity.class);
                intent.putExtra("NuovoAllenamento", (Parcelable) allenamento);
                startActivity(intent);
            } else {
                Toast.makeText(this, R.string.nonUnivoco, Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, R.string.senzaNomeAllenamento, Toast.LENGTH_SHORT).show();
        }
    }

    private boolean controlloNomeUnivocoAllenamento(Allenamento nuovoAllenamento) {
        FileInputStream fis = null;
        ObjectInputStream is;
        try {
            fis = openFileInput(AllenamentoActivity.file);
            is = new ObjectInputStream(fis);
            ArrayList<Allenamento> allenamenti = (ArrayList<Allenamento>) is.readObject();
            for (Allenamento temp : allenamenti) {
                if (temp.getNome().equalsIgnoreCase(nuovoAllenamento.getNome()))
                    return false;
            }
            is.close();
            fis.close();
        } catch (IOException | ClassNotFoundException e) {
            //Log.i("caricaDaFile", "FILE NON PRESENTE");
        }
        return true;
    }

    public void aggiungiEsercizio(View view) {
        CustomDialogEsercizio.showCustomDialog(NuovoAllenamentoActivity.this, new CustomDialogEsercizio.OnCompleteListener() {
            @Override
            public void onComplete(String nome, int numSerie, int numRipetizioni, int tempoRecupero) {
                esercizi.add(new Esercizio(formattaStringa(nome), numSerie, numRipetizioni, tempoRecupero));
                //Log.i("STRINGA PESI",esercizi.get(esercizi.size()-1).toStringPeso());
                //Log.i("NUMERO ELEMENTI",esercizi.size()+"");
                adapterEsercizi.add(esercizi.get(esercizi.size() - 1).toString());
            }
        }, "", -1, -1, -1);
    }

    private String formattaStringa(String input) {
        input = input.trim();
        StringBuilder result = new StringBuilder();
        boolean toUpperCase = true;

        for (char c : input.toCharArray()) {
            if (Character.isWhitespace(c)) {
                toUpperCase = true;
            } else {
                if (toUpperCase) {
                    result.append(" ");
                    result.append(Character.toUpperCase(c));
                    toUpperCase = false;
                } else {
                    result.append(Character.toLowerCase(c));
                }
            }
        }
        return result.toString();   //La prima lettera di ogni parola è maiuscola; c'è solo uno spazio fra le parole
    }

    public void modificaEliminaEsercizio(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.opzioniEsercizio)
                .setNeutralButton(R.string.annulla, null)
                .setNegativeButton(R.string.modifica, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        modificaEsercizio(position);
                    }
                })
                .setPositiveButton(R.string.elimina, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        eliminaEsercizio(position);
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(NuovoAllenamentoActivity.this, R.color.actionBarBackground));
                alertDialog.getButton(DialogInterface.BUTTON_NEUTRAL).setTextColor(ContextCompat.getColor(NuovoAllenamentoActivity.this, R.color.actionBarBackground));
                alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(NuovoAllenamentoActivity.this, R.color.actionBarBackground));
            }
        });
        alertDialog.show();
    }

    public void modificaEsercizio(int position) {
        CustomDialogEsercizio.showCustomDialog(NuovoAllenamentoActivity.this, new CustomDialogEsercizio.OnCompleteListener() {
            @Override
            public void onComplete(String nome, int numSerie, int numRipetizioni, int tempoRecupero) {
                adapterEsercizi.remove(esercizi.get(position).toString());
                esercizi.remove(position);
                esercizi.add(position,new Esercizio(formattaStringa(nome), numSerie, numRipetizioni, tempoRecupero));
                adapterEsercizi.insert(esercizi.get(position).toString(),position);
                adapterEsercizi.notifyDataSetChanged();
            }
        }, esercizi.get(position).getNome(), esercizi.get(position).getNumSerie(), esercizi.get(position).getNumRipetizioni(), esercizi.get(position).getTempoRecupero());
    }

    public void eliminaEsercizio(int position) {
        esercizi.remove(position);
        adapterEsercizi.clear();
        for (Esercizio temp : esercizi) {
            adapterEsercizi.add(temp.toString());
        }
    }
}
