package com.example.polofitness;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class GraficoEsercizioActivity extends AppCompatActivity {

    private ArrayList<Esercizio> esercizi;
    private ListView listEserciziDiAllenamento;
    private ArrayAdapter adapter;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grafico_esercizio);

        listEserciziDiAllenamento = findViewById(R.id.listEsercizio);
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1) {
            @NonNull
            @Override
            public View getView(int position, View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = view.findViewById(android.R.id.text1);
                textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                return view;
            }
        };
        listEserciziDiAllenamento.setAdapter(adapter);

        Intent intent = getIntent();
        if (intent != null) {
            esercizi = new ArrayList<>();
            int size = intent.getIntExtra("NumeroEsercizi", -1);
            for (int i = 0; i < size; i++) {
                Esercizio temp = intent.getParcelableExtra("Esercizio" + i);
                if (temp != null) {
                    esercizi.add(temp);
                }
            }
        }
        //aggiunta esercizi alla listView
        for (Esercizio esercizio : esercizi) {
            adapter.add(esercizio.toString() + " " + getResources().getString(R.string.pesi) + " " + esercizio.toStringPeso());
        }
       /* for (Esercizio e : esercizi) {
            Log.i("RICEVUTI", e.toStringPeso());
        }*/

        creaGrafico();

    }

    public void creaGrafico(){
        BarChart barChart = findViewById(R.id.barChart);
        barChart.getLegend().setEnabled(false);
        barChart.getDescription().setEnabled(false);
        barChart.moveViewToX(Math.max(0, esercizi.size() - 7)); //posizione iniziale dell'asse x
        barChart.setDragEnabled(true);
        barChart.setScaleEnabled(false);

        ArrayList<BarEntry> barEntries = new ArrayList<>();
        for (int i = 0; i < esercizi.size(); i++) {
            barEntries.add(new BarEntry(i, esercizi.get(i).mediaPesiUsati()));
        }

        BarDataSet barDataSet = new BarDataSet(barEntries, "Pesi degli Esercizi");
        barDataSet.setColors(Color.rgb(232, 45, 45));   //=R.color.actionBarBackground
        barDataSet.setValueTextSize(12f);   //dimensione testo sopra barre

        BarData barData = new BarData(barDataSet);
        barChart.setData(barData);
        barChart.setVisibleXRangeMaximum(7); //numero massimo di barre visualizzate contemporaneamente

        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setTextSize(12f);
        xAxis.setDrawGridLines(false);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return new DecimalFormat("#").format(value+1);
            }
        });
        xAxis.setLabelCount(Math.min(esercizi.size(), 7), false);

        YAxis yAxis = barChart.getAxisRight();
        yAxis.setEnabled(false); //disabilita l'asse Y destro
        yAxis = barChart.getAxisLeft();
        yAxis.setDrawGridLinesBehindData(true); //disegna righe dietro barre
        yAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return new DecimalFormat("#.0").format(value) + " Kg";
            }
        });
    }
}