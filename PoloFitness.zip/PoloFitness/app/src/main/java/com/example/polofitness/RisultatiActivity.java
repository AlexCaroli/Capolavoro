package com.example.polofitness;

import static com.example.polofitness.IniziaAllenamentoActivity.file;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class RisultatiActivity extends AppCompatActivity {
    private File risultati;
    private ArrayList<Allenamento> allenamenti;
    private ArrayList<ArrayList<Esercizio>> listaEsercizi;
    private TextView txtTitoloElenco;
    private ListView listElenco;
    private boolean tipoVista;
    private ArrayAdapter<String> adapter;
    private Map<String, ArrayList<Esercizio>> mappaEsercizi = new HashMap<>();

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_risultati);

        ActionBar actionBar = getSupportActionBar();
        actionBar.show();

        txtTitoloElenco = findViewById(R.id.txtTitoloElenco);
        listElenco = findViewById(R.id.listElenco);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        listElenco.setAdapter(adapter);
        caricaDaFile();

        mostraAllenamenti();

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Intent intent = new Intent(RisultatiActivity.this, MainActivity.class);
                startActivity(intent);
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    public void cambiaVista(MenuItem item) {
        adapter.clear();
        adapter.notifyDataSetChanged();
        if (tipoVista) {
            txtTitoloElenco.setText(R.string.allenamentiFatti);
            item.setTitle(R.string.cambiaVista1);
            mostraAllenamenti();
            tipoVista = false;
        } else {
            txtTitoloElenco.setText(R.string.eserciziFatti);
            item.setTitle(R.string.cambiaVista2);
            mostraEsercizi();
            tipoVista = true;
        }
    }

    public void mostraEsercizi() {
        listaEsercizi = ottieniListaEsercizi(allenamenti);

        // Puliamo la mappa prima di riempirla
        mappaEsercizi.clear();

        // Creiamo una lista temporanea per contenere i nomi degli esercizi
        ArrayList<String> nomiEsercizi = new ArrayList<>();
        for (ArrayList<Esercizio> listaStessiEsercizi : listaEsercizi) {
            nomiEsercizi.add(listaStessiEsercizi.get(0).getNome());
            // Aggiungiamo il nome dell'esercizio come chiave e la lista degli esercizi come valore nella mappa
            mappaEsercizi.put(listaStessiEsercizi.get(0).getNome(), listaStessiEsercizi);
        }

        // Ordiniamo la lista di nomi degli esercizi in ordine alfabetico
        Collections.sort(nomiEsercizi);

        // Puliamo l'adapter e aggiungiamo gli esercizi ordinati
        adapter.clear();
        adapter.addAll(nomiEsercizi);

        listElenco.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String nomeEsercizioSelezionato = adapter.getItem(position);
                mostraGraficoEsercizio(nomeEsercizioSelezionato);
            }
        });
        listElenco.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                return true;
            }
        });
    }

    private ArrayList<ArrayList<Esercizio>> ottieniListaEsercizi(ArrayList<Allenamento> allenamenti) {
        Map<String, ArrayList<Esercizio>> mappaEsercizi = new HashMap<>();

        for (Allenamento allenamento : allenamenti) {
            for (Esercizio esercizio : allenamento.getEsercizi()) {
                String nomeEsercizio = esercizio.getNome();

                if (!mappaEsercizi.containsKey(nomeEsercizio)) {// Se il nome dell'esercizio non è ancora presente nella mappa, aggiungi una nuova lista
                    mappaEsercizi.put(nomeEsercizio, new ArrayList<>());
                }
                mappaEsercizi.get(nomeEsercizio).add(esercizio); // Aggiungi l'esercizio alla lista corrispondente al nome
            }
        }
        return new ArrayList<>(mappaEsercizi.values());// Restituisci una lista di tutte le liste di esercizi
    }

    public void mostraGraficoEsercizio(String nomeEsercizio) {
        ArrayList<Esercizio> eserciziCorrispondenti = mappaEsercizi.get(nomeEsercizio);
        if (eserciziCorrispondenti != null && eserciziCorrispondenti.size() > 0) {
            Intent intent = new Intent(this, GraficoEsercizioActivity.class);
            for (int i = 0; i < eserciziCorrispondenti.size(); i++) {
                intent.putExtra("Esercizio" + i, (Parcelable) eserciziCorrispondenti.get(i));
            }
            intent.putExtra("NumeroEsercizi", eserciziCorrispondenti.size());
            startActivity(intent);
        } else {
            // Gestione dell'errore se non ci sono esercizi corrispondenti
            Log.e("RisultatiActivity", "Nessun esercizio corrispondente per: " + nomeEsercizio);
        }
    }

    public void mostraAllenamenti() {
        for(int i = allenamenti.size()-1; i >= 0; i--)
            adapter.add(allenamenti.get(i).toStringData());
        /*for (Allenamento temp : allenamenti) {
            adapter.add(temp.toStringData());
        }*/
        listElenco.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mostraGraficoAllenamento(position);
            }
        });
        listElenco.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                eliminaAllenamento(position);
                return true;
            }
        });
    }

    public void mostraGraficoAllenamento(int position) {
        Intent intent = new Intent(this, GraficoAllenamentoActivity.class);
        intent.putExtra("AllenamentoMostrato", (Parcelable) allenamenti.get(allenamenti.size() - 1 - position));
        intent.putExtra("IndiceAllenamento",position);
        startActivity(intent);
    }

    public void eliminaAllenamento(int position) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.opzioniAllenamento)
                .setNegativeButton(R.string.annulla, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .setPositiveButton(R.string.elimina, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        allenamenti.remove(position);
                        salvaSuFile();
                        adapter.clear();
                        for (Allenamento temp : allenamenti) {
                            adapter.add(temp.toStringData());
                        }
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(RisultatiActivity.this, R.color.actionBarBackground));
                alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(RisultatiActivity.this, R.color.actionBarBackground));
            }
        });
        alertDialog.show();
    }

    public void salvaSuFile() {
        FileOutputStream fos = null;
        ObjectOutputStream os = null;
        try {
            fos = openFileOutput(file, Context.MODE_PRIVATE);
            os = new ObjectOutputStream(fos);
            os.writeObject(allenamenti);
            os.close();
            fos.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void caricaDaFile() {
        FileInputStream fis = null;
        ObjectInputStream is;
        try {
            fis = openFileInput(file);
            is = new ObjectInputStream(fis);
            allenamenti = (ArrayList<Allenamento>) is.readObject();
            is.close();
            fis.close();
        } catch (IOException | ClassNotFoundException e) {
            risultati = new File(file);
            allenamenti = new ArrayList<>();
        }
    }
}
