package com.example.polofitness;

import java.util.ArrayList;

public interface CustomDialogPesoListener {
    void onSaveClicked(ArrayList<String> pesiInseriti);
}
