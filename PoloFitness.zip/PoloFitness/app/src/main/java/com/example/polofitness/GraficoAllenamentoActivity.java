package com.example.polofitness;

import static com.example.polofitness.IniziaAllenamentoActivity.file;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class GraficoAllenamentoActivity extends AppCompatActivity implements CustomDialogPesoListener{

    private Allenamento allenamento;
    private int indiceAllenamento;
    private ListView listEserciziDiAllenamento;
    private ArrayAdapter adapter;
    private File risultati;

    private int ultimoElementoCliccato;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grafico_allenamento);

        listEserciziDiAllenamento = findViewById(R.id.listEserciziDiAllenamento);
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1){
            @NonNull
            @Override
            public View getView(int position, View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = view.findViewById(android.R.id.text1);
                textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                return view;
            }
        };
        listEserciziDiAllenamento.setAdapter(adapter);

        Intent intent = getIntent();
        if (intent != null) {
            Allenamento temp = intent.getParcelableExtra("AllenamentoMostrato");
            indiceAllenamento = intent.getIntExtra("IndiceAllenamento",-1);
            if (temp != null) {
                allenamento = temp;
            }
        }
        Log.i("DATA ALLENAMENTO",allenamento.toStringData());
        //aggiunta esercizi alla listView
        for(Esercizio esercizio : allenamento.getEsercizi()) {
            adapter.add(esercizio.toString() + " " + getResources().getString(R.string.pesi) + " " + esercizio.toStringPeso());
        }

        listEserciziDiAllenamento.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                modificaEsercizio(position);
                return true;
            }
        });

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Intent intent = new Intent(GraficoAllenamentoActivity.this, RisultatiActivity.class);
                startActivity(intent);
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);
        creaGrafico();
    }

    public void creaGrafico() {
        BarChart barChart = findViewById(R.id.barChart);
        barChart.getLegend().setEnabled(false);
        barChart.getDescription().setEnabled(false);
        barChart.setScaleEnabled(false);    //disabilita lo zoom nel grafico

        ArrayList<BarEntry> barEntries = new ArrayList<>();
        for(int i = 0; i < allenamento.getEsercizi().size(); i++) {
            barEntries.add(new BarEntry(i, allenamento.getEsercizio(i).mediaPesiUsati()));
        }

        BarDataSet barDataSet = new BarDataSet(barEntries, String.valueOf(R.string.pesi));
        barDataSet.setColors(Color.rgb(232,45,45)); //=R.color.actionBarBackground
        barDataSet.setValueTextSize(12f);   //dimensione testo sopra barre

        BarData barData = new BarData(barDataSet);
        barChart.setData(barData);
        barChart.setVisibleXRangeMaximum(7); //numero massimo di barre visualizzate contemporaneamente

        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setTextSize(12f);
        xAxis.setDrawGridLines(false);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return allenamento.getEsercizi().get((int)value).getNome();
            }
        });
        xAxis.setLabelRotationAngle(20f);
        xAxis.setLabelCount( Math.min(allenamento.getEsercizi().size(), 7), false);

        YAxis yAxis= barChart.getAxisRight();
        yAxis.setEnabled(false); //disabilita l'asse Y destro
        yAxis = barChart.getAxisLeft();
        yAxis.setDrawGridLinesBehindData(true); //disegna righe dietro barre
        yAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return new DecimalFormat("#.0").format(value)  + " Kg";
            }
        });
        barChart.invalidate();
    }
    public void modificaEsercizio(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.opzioniAllenamento)
                .setNegativeButton(R.string.annulla, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .setPositiveButton(R.string.modifica, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        modifica(position);
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(GraficoAllenamentoActivity.this, R.color.actionBarBackground));
                alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(GraficoAllenamentoActivity.this, R.color.actionBarBackground));
            }
        });
        alertDialog.show();
    }
    public void modifica(int position){
        ultimoElementoCliccato = position;
        CustomDialogPeso customDialog = new CustomDialogPeso(allenamento.getEsercizio(position));
        customDialog.setCustomDialogListener(this);

        FragmentManager fragmentManager = getSupportFragmentManager();
        customDialog.show(fragmentManager, "CustomDialog");
    }
    @Override
    public void onSaveClicked(ArrayList<String> pesiInseriti) {
        ArrayList<Float> pesiUsati = new ArrayList<>();
        for (int i = 0; i < pesiInseriti.size(); i++) {
            try {
                if (Float.parseFloat(pesiInseriti.get(i)) != -1)
                    pesiUsati.add(Float.parseFloat(pesiInseriti.get(i)));
            } catch (
                    NumberFormatException ex) {  //non è stato inserito il valore nella CustomDialgPeso
                pesiUsati.add((float) -1);
            }
        }
        allenamento.getEsercizio(ultimoElementoCliccato).setPesiUsati(pesiUsati);

        for(int i = 0; i< allenamento.getEsercizio(ultimoElementoCliccato).getNumSerie(); i++){
            if (allenamento.getEsercizio(ultimoElementoCliccato).getPesoUsato(i) == -1) {
                allenamento.getEsercizio(ultimoElementoCliccato).setPesoUsato(0f, i);
            }
            //Log.i("PESO " + i, allenamento.getEsercizio(ultimoElementoCliccato).getPesoUsato(i)+"");
        }
        adapter.clear();
        for(Esercizio esercizio : allenamento.getEsercizi()) {
            adapter.add(esercizio.toString() + " " + getResources().getString(R.string.pesi) + " " + esercizio.toStringPeso());
        }
        salvaSuFile(allenamento);
        creaGrafico();
    }
    public void salvaSuFile(Allenamento nuovoAllenamento) {
        FileOutputStream fos = null;
        ObjectOutputStream os = null;
        ArrayList<Allenamento> allenamenti = caricaDaFile();
        nuovoAllenamento.setData(allenamenti.get(indiceAllenamento).getData()); //dato che LocalDateTime non implementa l'interfaccia Parcelable, la recupero da file sapendo l'indice dell'allenamento che sto modificando
        allenamenti.set(indiceAllenamento,nuovoAllenamento);
        try {
            fos = openFileOutput(file, Context.MODE_PRIVATE);
            os = new ObjectOutputStream(fos);
            os.writeObject(allenamenti);
            os.close();
            fos.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public ArrayList<Allenamento> caricaDaFile() {
        FileInputStream fis = null;
        ObjectInputStream is;
        ArrayList<Allenamento> allenamenti;
        try {
            fis = openFileInput(file);
            is = new ObjectInputStream(fis);

            allenamenti = (ArrayList<Allenamento>) is.readObject();
            //Log.i("caricaDaFileIniziaAllenamento", "HO LETTO GLI OGGETTI GIA' PRESENTI");
            is.close();
            fis.close();
            return allenamenti;
        } catch (IOException | ClassNotFoundException e) {
            risultati = new File(file);
            //Log.i("caricaDaFileIniziaAllenamento", "FILE NON PRESENTE");
            return new ArrayList<>();
        }
    }
}

