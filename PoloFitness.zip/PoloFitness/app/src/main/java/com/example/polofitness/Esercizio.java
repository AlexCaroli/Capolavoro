package com.example.polofitness;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.io.Serializable;
import java.util.ArrayList;

public class Esercizio implements Parcelable, Serializable, Comparable<Esercizio> {
    private String nome;
    private int numSerie;
    private int numRipetizioni;
    private int tempoRecupero;  //in secondi
    private ArrayList<Float> pesiUsati;

    public Esercizio(String nome, int numSerie, int numRipetizioni, int tempoRecupero) {
        this.nome = nome;
        this.numSerie = numSerie;
        this.numRipetizioni = numRipetizioni;
        this.tempoRecupero = tempoRecupero;
        pesiUsati = new ArrayList<>(numSerie);
        for (int i = 0; i < numSerie; i++) {    //imposta i pesi usati a -1 di default, serve per il funzionamento della CustomDialogPeso
            pesiUsati.add(-1f);
        }
    }


    public ArrayList<Float> getPesiUsati() {
        return pesiUsati;
    }

    public void setPesiUsati(ArrayList<Float> pesiUsati) {
        this.pesiUsati = pesiUsati;
    }

    public float getPesoUsato(int position) {
        return pesiUsati.get(position);
    }

    public void setPesoUsato(Float pesoUsato, int position) {
        this.pesiUsati.set(position, pesoUsato);
    }

    public String getNome() {
        return nome;
    }

    public int getNumSerie() {
        return numSerie;
    }

    public int getNumRipetizioni() {
        return numRipetizioni;
    }

    public int getTempoRecupero() {
        return tempoRecupero;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public float mediaPesiUsati() {
        float media = 0;
        for (int i = 0; i < numSerie; i++) {
            media += pesiUsati.get(i);
        }
        return media /= numSerie;
    }

    @NonNull
    @Override
    public String toString() {
        return nome + " " + numSerie + "x" + numRipetizioni + " " + tempoRecupero;
    }

    public String toStringPeso() {
        String s = " ";
        for (int i = 0; i < numSerie - 1; i++) {
            s += pesiUsati.get(i) + ", ";
        }
        s += pesiUsati.get(numSerie - 1);
        return s;
    }

    //metodo interfaccia Comparable
    @Override
    public int compareTo(Esercizio altroEsercizio) {
        return this.getNome().compareTo(altroEsercizio.getNome());
    }

    //metodi interfacci Parcelable
    protected Esercizio(Parcel in) {
        nome = in.readString();
        numSerie = in.readInt();
        numRipetizioni = in.readInt();
        tempoRecupero = in.readInt();
        pesiUsati = new ArrayList<>();
        in.readList(pesiUsati, Float.class.getClassLoader());
    }

    public static final Creator<Esercizio> CREATOR = new Creator<Esercizio>() {
        @Override
        public Esercizio createFromParcel(Parcel in) {
            return new Esercizio(in);
        }

        @Override
        public Esercizio[] newArray(int size) {
            return new Esercizio[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nome);
        dest.writeInt(numSerie);
        dest.writeInt(numRipetizioni);
        dest.writeInt(tempoRecupero);
        dest.writeList(pesiUsati);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
