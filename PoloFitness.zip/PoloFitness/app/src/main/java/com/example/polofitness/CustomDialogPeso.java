package com.example.polofitness;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;

import java.util.ArrayList;


public class CustomDialogPeso extends DialogFragment {
    private ArrayList<String> pesiInseriti;
    private CustomDialogPesoListener mListener;
    private Esercizio esercizio;

    public CustomDialogPeso(Esercizio esercizio) {
        this.esercizio = esercizio;
        pesiInseriti = new ArrayList<>();
        for (int i = 0; i < esercizio.getNumSerie(); i++)
            pesiInseriti.add("");
    }

    public void setCustomDialogListener(CustomDialogPesoListener listener) {
        this.mListener = listener;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();

        View view = inflater.inflate(R.layout.custom_dialog_peso, null);
        builder.setView(view);

        LinearLayout linearLayout = view.findViewById(R.id.linearLayoutDialog);
        TextView txtNomeEsercizio = view.findViewById(R.id.txtNomeEsercizio);
        txtNomeEsercizio.setText(esercizio.getNome());

        for (int i = 0; i < esercizio.getNumSerie(); i++) {
            View item = inflater.inflate(R.layout.custom_dialog_peso_item, null);
            TextView strPeso = item.findViewById(R.id.strPeso);
            EditText txtPeso = item.findViewById(R.id.txtPeso);

            strPeso.setText(getString(R.string.serie) + " " + (i + 1));
            if (esercizio.getPesiUsati().get(i) != -1) {    //se la serie dell'esercizio ha già un peso, lo mostra nell'editText
                txtPeso.setText(esercizio.getPesiUsati().get(i) + "");
                pesiInseriti.set(i, esercizio.getPesiUsati().get(i) + "");
            }
            linearLayout.addView(item);

            //Aggiunta listener per ogni editText
            final int serieIndex = i;  //tiene traccia dell'indice della serie
            txtPeso.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                }

                @Override
                public void afterTextChanged(Editable editable) {
                    pesiInseriti.set(serieIndex, editable.toString());
                }
            });
        }

        builder.setPositiveButton(R.string.salva, new DialogInterface.OnClickListener() {   //quando l'utente clicca su Salva, i pesi inseriti vengono passati al listener esterno
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (mListener != null) {
                    mListener.onSaveClicked(pesiInseriti);
                }
            }
        });
        builder.setNegativeButton(R.string.annulla, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        return builder.create();
    }

    public void onStart() {
        super.onStart();
        Button positiveButton = ((AlertDialog) getDialog()).getButton(DialogInterface.BUTTON_POSITIVE);
        Button negativeButton = ((AlertDialog) getDialog()).getButton(DialogInterface.BUTTON_NEGATIVE);

        positiveButton.setTextColor(ContextCompat.getColor(requireContext(), R.color.actionBarBackground));
        negativeButton.setTextColor(ContextCompat.getColor(requireContext(), R.color.actionBarBackground));
    }
}