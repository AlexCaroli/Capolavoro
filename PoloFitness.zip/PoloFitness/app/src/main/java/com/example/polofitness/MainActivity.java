package com.example.polofitness;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);
    }
    public void openNewActivity(View view) {
        Intent intent = new Intent();
        if (view.getId() == R.id.btn_allenamento)
            intent = new Intent(this, AllenamentoActivity.class);
        else if (view.getId() == R.id.btn_risultati)
            intent = new Intent(this, RisultatiActivity.class);
        startActivity(intent);
    }
}