package com.example.polofitness;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;

public class CustomDialogEsercizio {

    public interface OnCompleteListener {
        void onComplete(String nome, int numSerie, int numRipetizioni, int tempoRecupero);
    }

    public static void showCustomDialog(Context context, final OnCompleteListener listener, String nome, int numSerie, int numRipetizioni, int tempoRecupero) {
        //Crea un oggetto View con il layout personalizzato
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.custom_dialog_esercizio, null);

        EditText txtNome = view.findViewById(R.id.strNome);
        EditText txtNumSerie = view.findViewById(R.id.txtNumSerie);
        EditText txtNumRipetizioni = view.findViewById(R.id.txtNumRipetizioni);
        EditText txtTempoRecupero = view.findViewById(R.id.txtTempoRecupero);

        //se si sta modificando un esercizio esistente imposta i suoi valori negli editText
        if (!nome.equals(""))
            txtNome.setText(nome);
        if (numSerie != -1)
            txtNumSerie.setText(String.valueOf(numSerie));
        if (numRipetizioni != -1)
            txtNumRipetizioni.setText(String.valueOf(numRipetizioni));
        if (tempoRecupero != -1)
            txtTempoRecupero.setText(String.valueOf(tempoRecupero));

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        AlertDialog alertDialog = builder.setView(view)
                .setTitle(R.string.nuovoEsercizio)
                .setPositiveButton(R.string.salva, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String nome = txtNome.getText().toString();
                        if(!nome.trim().isEmpty()) {
                            int numSerie, numRipetizioni, tempoRecupero;
                            try {
                                numSerie = Integer.parseInt(txtNumSerie.getText().toString());
                            } catch (NumberFormatException ex) {
                                numSerie = 4;
                            }
                            try {
                                numRipetizioni = Integer.parseInt(txtNumRipetizioni.getText().toString());
                            } catch (NumberFormatException ex) {
                                numRipetizioni = 10;
                            }
                            try {
                                tempoRecupero = Integer.parseInt(txtTempoRecupero.getText().toString());
                            } catch (NumberFormatException ex) {
                                tempoRecupero = 60;
                            }
                            listener.onComplete(nome, numSerie, numRipetizioni, tempoRecupero);
                        }else {
                            Toast.makeText(context, R.string.senzaNomeEsercizio, Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton(R.string.annulla, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(context, R.color.actionBarBackground));
                alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(context, R.color.actionBarBackground));
            }
        });
        alertDialog.show();
    }
}
